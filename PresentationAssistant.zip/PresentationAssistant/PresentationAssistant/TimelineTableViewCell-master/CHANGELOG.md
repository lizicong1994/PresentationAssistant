# Changelog

## Version 1.2
- Add a illustration

## Version 1.1
- Migrate to Swift 4
- Fix the issue: [There is a tiny white line between the arrow and the bubble in demo project.](https://github.com/kf99916/TimelineTableViewCell/issues/7)

## Version 1.0.1

- Make the default font be large to easy to read
- Line Info Label's CenterY is now equalTo Description Label's CenterY

## Version 1.0

- Initial version
